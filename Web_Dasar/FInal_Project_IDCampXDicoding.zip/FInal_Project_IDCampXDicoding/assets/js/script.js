function loading() {
    setTimeout(show, 2000);
}

function show() {
    document.getElementById("loadscreen").style.display = "block";
}